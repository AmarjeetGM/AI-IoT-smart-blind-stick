Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
Traceback (most recent call last):
  File "C:/Users/ankit/OneDrive/Desktop/prjct.py", line 3, in <module>
    import cvlib as cv
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\__init__.py", line 8, in <module>
    from .gender_detection import detect_gender
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\gender_detection.py", line 3, in <module>
    from tensorflow.keras.utils import get_file
ModuleNotFoundError: No module named 'tensorflow'
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
Traceback (most recent call last):
  File "C:/Users/ankit/OneDrive/Desktop/prjct.py", line 3, in <module>
    import cvlib as cv
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\__init__.py", line 8, in <module>
    from .gender_detection import detect_gender
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\gender_detection.py", line 3, in <module>
    from tensorflow.keras.utils import get_file
ModuleNotFoundError: No module named 'tensorflow'
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
Traceback (most recent call last):
  File "C:/Users/ankit/OneDrive/Desktop/prjct.py", line 3, in <module>
    import cvlib as cv
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\__init__.py", line 8, in <module>
    from .gender_detection import detect_gender
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\gender_detection.py", line 3, in <module>
    from tensorflow.keras.utils import get_file
ModuleNotFoundError: No module named 'tensorflow'
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
Traceback (most recent call last):
  File "C:/Users/ankit/OneDrive/Desktop/prjct.py", line 3, in <module>
    import cvlib as cv
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\__init__.py", line 8, in <module>
    from .gender_detection import detect_gender
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\gender_detection.py", line 3, in <module>
    from tensorflow.keras.utils import get_file
ModuleNotFoundError: No module named 'tensorflow'
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
Traceback (most recent call last):
  File "C:/Users/ankit/OneDrive/Desktop/prjct.py", line 3, in <module>
    import cvlib as cv
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\__init__.py", line 8, in <module>
    from .gender_detection import detect_gender
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\gender_detection.py", line 3, in <module>
    from tensorflow.keras.utils import get_file
ModuleNotFoundError: No module named 'tensorflow'
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
Traceback (most recent call last):
  File "C:/Users/ankit/OneDrive/Desktop/prjct.py", line 3, in <module>
    import cvlib as cv
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\__init__.py", line 8, in <module>
    from .gender_detection import detect_gender
  File "C:\Users\ankit\AppData\Local\Programs\Python\Python39\lib\site-packages\cvlib\gender_detection.py", line 3, in <module>
    from tensorflow.keras.utils import get_file
ModuleNotFoundError: No module named 'tensorflow'
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============

=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 
=============== RESTART: C:/Users/ankit/OneDrive/Desktop/prjct.py ==============
started
>>> 